Schurr operational restore checker

This code-only kit matches schema f8a05b0c930af1d5a50cfc2151383883ec1d526519cf4060616ce39ddd29b133. It contains no business data or credentials.

Requires Node.js 22.13 or newer. Extract this archive, then open a terminal in the extracted schurr-operational-restore folder. Keep your privately downloaded JSON backup outside any public/shared folder. Run:

node scripts/restore-operational-backup.cjs --input /absolute/path/to/schurr-operational-backup.json --output /absolute/path/to/NEW-isolated-archive.sqlite

Choose a NEW output file outside this kit/application folder; existing files are never overwritten. The checker uses only local files and SQLite. No connection to Schurr, Google, Retell or Resend is made. Success reports OFFLINE_INSPECTION_ONLY. You can inspect the resulting file with a local SQLite viewer.

IMPORTANT SCOPE: Operational records only. Secrets, runtime variables, provider connections, transient rate limits/delays and current sending approvals are excluded. All pending sends and open follow-ups become inactive. Booking/handoff/chat are disabled; current launch evidence and simulations become stale. Existing appointments, notes, tasks, suppressions, operational receipts and historical events are retained. Monitoring alerts and the expected background runner are disabled; the approved baseline and runner heartbeat are cleared, and restored check results are marked unknown. Monitoring notification sender/recipient payloads, connection fingerprints, admission tokens, leases and retry controls are excluded; restored notifications cannot be retried. Historical notification acceptance and attempt facts remain available. Gmail client credentials, mailbox connections and OAuth states are excluded. Gmail message and reply history, immutable message content, provider receipts and first-attempt facts are retained; pending messages become cancelled or uncertain, send leases are cleared, and transient reply import tokens are excluded. Gmail stays disconnected. Original changed records are preserved in operational_restore_changes.

DO NOT attach this database to a Worker, application server, production system or live environment. DO NOT supply provider keys/runtime secrets. This checker is not a production restoration workflow. A reviewed migration and fresh connection/permission checks would be required for any future production recovery.

If schema validation fails, use the restore kit from the same application version as the backup. Do not remove validation or edit SQL to force a restore.
