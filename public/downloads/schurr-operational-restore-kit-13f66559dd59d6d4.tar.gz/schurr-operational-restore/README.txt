Schurr operational restore checker

This code-only kit matches schema 13f66559dd59d6d44fbf73e154c7db5c63bec7c61966087ec1e549c718474292. It contains no business data or credentials.

Requires Node.js 22.13 or newer. Extract this archive, then open a terminal in the extracted schurr-operational-restore folder. Keep your privately downloaded JSON backup outside any public/shared folder. Run:

node scripts/restore-operational-backup.cjs --input /absolute/path/to/schurr-operational-backup.json --output /absolute/path/to/NEW-isolated-archive.sqlite

Choose a NEW output file outside this kit/application folder; existing files are never overwritten. The checker uses only local files and SQLite. No connection to Schurr, Google, Retell or Resend is made. Success reports OFFLINE_INSPECTION_ONLY. You can inspect the resulting file with a local SQLite viewer.

IMPORTANT SCOPE: Operational records only. Secrets, runtime variables, provider connections, transient rate limits/delays and current sending approvals are excluded. All pending sends and open follow-ups become inactive. Booking/handoff/chat are disabled; current launch evidence and simulations become stale. Existing appointments, notes, tasks, suppressions, receipts, payloads and historical events are retained. Original changed records are preserved in operational_restore_changes.

DO NOT attach this database to a Worker, application server, production system or live environment. DO NOT supply provider keys/runtime secrets. This checker is not a production restoration workflow. A reviewed migration and fresh connection/permission checks would be required for any future production recovery.

If schema validation fails, use the restore kit from the same application version as the backup. Do not remove validation or edit SQL to force a restore.
